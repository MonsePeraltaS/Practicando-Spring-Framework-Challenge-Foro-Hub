package com.example.forohub.controller;

import com.example.forohub.dto.TopicoRequest;
import com.example.forohub.model.Topico;
import com.example.forohub.repository.TopicoRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/topicos")
public class TopicoController {

    @Autowired
    private TopicoRepository repository;

    @PostMapping
    @Transactional
    public String registrar(@RequestBody @Valid TopicoRequest datos) {
        if (repository.existsByTituloAndMensaje(datos.getTitulo(), datos.getMensaje())) {
            return "Error: El tópico ya existe";
        }
        Topico topico = new Topico();
        topico.setTitulo(datos.getTitulo());
        topico.setMensaje(datos.getMensaje());
        topico.setAutor(datos.getAutor());
        topico.setCurso(datos.getCurso());
        topico.setStatus("ABIERTO");
        repository.save(topico);
        return "Tópico registrado con éxito";
    }

    @GetMapping
    public List<Topico> listar() {
        return repository.findAll();
    }
}